#ifndef WIFI_CONN_H
#define WIFI_CONN_H
void connect_to_wifi(const char *ssid, const char *password);
#endif